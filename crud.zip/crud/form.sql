-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2024 at 01:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crudoperation`
--

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(100) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` int(100) NOT NULL,
  `gender` enum('m','f','o') NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`id`, `name`, `lastname`, `email`, `password`, `phone`, `gender`, `comments`) VALUES
(1, 'sawan', 'kumar', 'Arun@gmail.com', 'Arun@123', 123456789, '', 'awam'),
(2, 'Kuanal ', 'sharma', 'kunla@gmail.com', 'k78278t812', 2147483647, '', 'fsdf'),
(3, 'kajal', 'kumari', 'kajal@gmail.com', 'Arun@123', 455868455, '', 'Hellow'),
(4, 'sawan', 'kumar', 'sawan@gmail.com', 'Ar099889678', 1215465, '', 'dytdyti'),
(5, 'sachin', 'bedi', 'sachin@gmail.com', '4546565465465456', 4648446, '', '654654'),
(6, 'gdf', 'ds', 'Arun@gmail.com', 'Arun@123', 4648446, '', '654654'),
(7, 'sahiii', 'fafdsf', 'Arun@gmail.com', 'Arun@123', 2147483647, '', 'fcsdaf'),
(8, 'sahiii', 'fafdsf', 'Arun@gmail.com', 'Arun@123', 2147483647, '', 'fcsdaf'),
(9, 'gdf', 'ds', 'Arun@gmail.com', 'Arun@123', 4648446, '', '654654'),
(10, 'gdf', 'ds', 'Arun@gmail.com', 'Arun@123', 4648446, '', '654654'),
(11, 'fhgdh', 'fdghf', 'Arun@gmail.com', 'Arun@123', 0, '', 'fgdhdfgh'),
(12, 'sahiii', 'fafdsf', 'Arun@gmail.com', 'Arun@123', 2147483647, '', 'fcsdaf'),
(13, 'sahiii', 'fafdsf', 'Arun@gmail.com', 'Arun@123', 2147483647, '', 'fcsdaf'),
(14, 'dev', 'chahun', 'Arun@gmail.com', 'Arun@123546', 4568455, '', 'hellow'),
(15, 'sahiii', 'fafdsf', 'Arun@gmail.com', 'Arun@123', 2147483647, '', 'fcsdaf'),
(16, 'Sawan', 'kmar', 'Arun@gmail.com', 'Arun@1233242', 12435456, '', 'csdfrsgshrthj'),
(17, 'Sawan', 'kmar', 'Arun@gmail.com', 'Arun@1233242', 12435456, '', 'csdfrsgshrthj'),
(18, 'Sawan', 'kmar', 'Arun@gmail.com', 'Arun@1233242', 12435456, '', 'csdfrsgshrthj');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
