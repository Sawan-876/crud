<?php

include "connect.php";

if(isset($_GET[' deleteid'])){
    $id = $_GET[' deleteid'];


    $sql = "delete from `form` where id= $id";
    $result = mysqli_query($conn,$sql);

    if($result){
            echo "Deteled";
    }

    else{
        die(mysqli_error($conn));
    }
}

?>