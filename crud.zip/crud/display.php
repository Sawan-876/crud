<?php
include "connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" 
    crossorigin="anonymous">

</head>
<body>
    <div class="container my-5">
        <button class="btn btn-primary"><a href="user.php" class="text-light">Add User</a> </button>
    
        <table class="table">
  <thead>
    <tr>
      <th scope="col">Sr.No</th>
      <th scope="col">Firstname</th>
      <th scope="col">Lastname</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Phone</th>
      <th scope="col">Gender</th>
      <th scope="col">Comments</th>
      <th scope="col">Operation</th>

    </tr>
  </thead>
  <tbody>

    <?php

    $sql = "select * from `form`";
    $result = mysqli_query($conn,$sql);

    if($result)
    {
       while($row = mysqli_fetch_assoc($result)){
        $id =  $row['id'];
        $fname =  $row['name'];
        $lname =  $row['lastname'];
        $email =  $row['email'];
        $pass = $row['password'];
        $phone = $row['phone'];
        $gender = $row['gender'];
        $cmt = $row['comments'];
        

        echo ' <tr>
        <th scope="row">'.$id.'</th>
        <td>'.$fname.'</td>
        <td>'.$lname.'</td>
        <td>'.$email.'</td>
        <td>'.$pass.'</td>
        <td>'.$phone.'</td>
        <td>'.$gender.'</td>
        <td>'.$cmt.'</td>
        <td>
        <button  class="btn btn-primary"><a href="update.php" class="text-light">Update</a></button>
        <button  class="btn btn-danger"><a href="delete.php? deleteid'.$id.'" class="text-light">Delete</a></button>
      </td>
      </tr>';

       }
    }

    ?>
   
  </tbody>
</table>
    </div>
</body>
</html>