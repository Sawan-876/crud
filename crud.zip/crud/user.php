<?php

include "connect.php";

if(isset($_POST['submit'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $cmt = $_POST['cmt'];

    $sql = "insert into `form`(id,name,lastname,email,password,phone,gender,comments) values('','$fname','$lname','$email','$pass','$phone','$gender','$cmt');";
    $result = mysqli_query($conn,$sql);


    if($result){
       header('location: display.php');
    }
    else{
        die(mysqli_error($conn));
    }
   
    $conn->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" 
    crossorigin="anonymous">
</head>
<body>
    <div class="container my-5">
    <form method="POST">

  <div class="mb-3">
    <label class="form-label">Full Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="fname" autocomplete="off">
  </div>

  <div class="mb-3">
    <label class="form-label">lastname</label>
    <input type="text" class="form-control" name="lname" autocomplete="off">
  </div>
 
  <div class="mb-3">
    <label class="form-label">E-Mail</label>
    <input type="email" class="form-control" name="email" autocomplete="off">
  </div>


  <div class="mb-3">
    <label class="form-label">Password</label>
    <input type="password" class="form-control" name="pass" autocomplete="off">
  </div>

  <div class="form-outline">
    <label class="form-label" for="typeNumber">Phone Number</label>
    <input type="number" id="typeNumber" name="phone" class="form-control" />
</div>


  <label class="form-label">Gender</label>
  <div class="form-check">
  <input type="radio" class="form-check-input" id="radio1" name="gender" value="Male" checked>Male
  <label class="form-check-label" for="radio1"></label>
</div>
<div class="form-check">
  <input type="radio" class="form-check-input" id="radio2" name="gender" value="Female">Female
  <label class="form-check-label" for="radio2"></label>
</div>
<div class="mb-3">
  <label  class="form-label">Comments</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" name="cmt" rows="3"></textarea>
</div>

  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>
    </div>
</body>
</html>